<?php
include "../includes/db.php";          
include "../includes/functions.php"; 
session_start(); 
if($_SESSION['user']==''){
	header("Location: choice.php");
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/mainprt2.css">
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body bgcolor="#193867" >
<div class='myheader' style="margin-left: 200px;">
	NAME : <?=strtoupper($_SESSION['user'])?> 
	<a href="../process/logout.php"><img src='../images/logoLogout.jpg'  width='20px' height='20px' align="right" style="margin-right: 5px;"></a>
</div>
<div class='sidenav'>
  <div align="center"><img src='../images/iccLogo.png'  width='150px' height='150px'></div>
<br/>
 <a href="../process/dashboard.php">Dashboard</a>
  <a href="#" onclick="alert('Under Maintenance!!!')">Reports</a>
</div>
<div style="margin-left: 200px;">
	<div class='lateButton'>
		<input type="button" onclick="reportLateStudent()" value="Report Late Student" style="margin:5px;background-color: #FF0000;color: #FFFFFF; border-radius: 15px; width: 200px;height: 40px; font-size: 18px">
	</div>
	<table class='tblestrand' width='100%'>
	<tr>
		<th width='30%'>Name</th>
		<th width='20%'>Section</th>
		<th width='10%'>Grade</th>
		<th width='20%'>Date</th>
		<th width='20%'>Time Arrival</th>
	</tr>
	</table>
</div>
</body>
<script>
	function reportLateStudent(){
		$parts = parse_url($url);
		parse_str($parts['query'], $query);
		alert("reporting late student from strand = "+$query['strand']);
	}
</script>
</html>
