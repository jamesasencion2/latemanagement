<?php
include "../includes/db.php";          
include "../includes/functions.php";          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/login.css">
 <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body  >
	<div class="bg-image"></div>
	<div class="bg-choice">
	<div align="right">  <a href='../process/choice.php'class='logbutton'>Back</a></div>
  <div><img src='../images/iccLogo.png'  width='250px' height='250px'></div>
  <div></div>
  <br/>
  <div><input type="button" name='txtPassword'value="LOGIN" class='buttonchoce' onclick="redirectF('../process/login.php')" style="margin-right: 50px ;">
  	<input type="button" value="SIGN-UP" class='buttonchoce' onclick="redirectF('../process/signup.php')"></div>
  <br/>
	
</div>
</body>
<script>
	function redirectF(url){
        window.location.href = url;

	}
</script>
</html>