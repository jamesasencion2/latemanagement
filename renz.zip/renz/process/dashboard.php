<?php
include "../includes/db.php";          
include "../includes/functions.php"; 
session_start(); 
if($_SESSION['user']==''){
	header("Location: choice.php");
}        
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/mainprt2.css">
    <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body bgcolor="#193867" >
	<!-- <div class="bg-image"></div> -->
	<!-- <div class="bg-text">
  <div>System Under Maintenance</div>	
  <br/><br/><br/><br/>
  <div><input type="button" value="Logout" class='buttonchoce' onclick="redirectF('../process/logout.php')"></div>	
</div> -->
  	
<div class='myheader' style="margin-left: 200px;">
	NAME : <?=strtoupper($_SESSION['user'])?> 
	<a href="../process/logout.php"><img src='../images/logoLogout.jpg'  width='20px' height='20px' align="right" style="margin-right: 5px;"></a>
</div>
<div class='sidenav'>
  <div align="center"><img src='../images/iccLogo.png'  width='150px' height='150px'></div>
<br/>
 <a href="../process/dashboard.php">Dashboard</a>
  <a href="#" onclick="alert('Under Maintenance!!!')">Reports</a>
</div>
<div class="mainText" align="center" >
	<div width="100%" style="margin:40px">
		<label><img src='../images/STSTRAND.png'   height='100px'><label>
	</div>
	<div width="100%" style="margin:10">
		<label><img src='../images/ICT.png'  width='200px' height='180px' onclick='strandFunc("ICT")'><label>
		<label style="margin-left:100px"><img src='../images/HE.png'  width='200px' height='180px' onclick='strandFunc("HE")'><label>
		<label style="margin-left:100px"><img src='../images/HUMSS.png'  width='200px' height='180px' onclick='strandFunc("HUMSS")'><label>
	</div>
	<div width="100%" style="margin:50px">
		<label><img src='../images/GAS.png'  width='200px' height='180px' onclick='strandFunc("GAS")'><label>
		<label style="margin-left:100px"><img src='../images/ABM.png'  width='200px' height='180px' onclick='strandFunc("ABM")'><label>
		<label style="margin-left:100px"><img src='../images/STEM.png'  width='200px' height='180px' onclick='strandFunc("STEM")'><label>
	</div>
</div>
</body>
<script>
	// function redirectF(url){
  //       window.location.href = url;
	// }


function strandFunc(strand){
	window.location.href = "../process/norelaoadTable.php?strand="+strand;
// $('.mainText > div').remove();

//     $.ajax({
//       url: "../process/norelaoadTable.php?strand="+strand,
//       type: "post",
//       data: {
//       	pStrand:strand,
//       },
//       success: function(response) {
//         $(".mainText").html(response);
//       }
//     });

	}
</script>
</html>