<?php
include "../includes/db.php";          
include "../includes/functions.php";          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/login.css">
    <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>
      <!-- <link rel='stylesheet' type='text/css' href='../design/gsheet.css'> -->
<!-- <link rel='stylesheet' type='text/css' href='../design/jquery-ui.css' /> -->
<!-- <script type='text/javascript' src='../js/jquery-ui.js'></script> -->
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Create Dummy Students</title>
</head>
<body  >
	<div class="bg-image"></div>
	<div class="bg-textsign" style="width: 34%;">
  <!-- <div><img src='../images/iccLogo.png'  width='150px' height='150px'></div> -->
  <!-- <br/> -->
  <div align="center"><h2>Create Dummy Students</h2></div>
  <!-- <br/> -->
  <div><input type="text" name='txtLName' placeholder="Last Name" class='logInput'></div>
  <br/>
  <div><input type="text" name='txtFName' placeholder="First Name" class='logInput'></div>
  <br/>
  <div><input type="text" name='txtMName' placeholder="Middle Name" class='logInput'></div>
  <br/>
  <div>
  	<select type="text" name='txtGender' class='Gender' >
  		<option value="">-Select Gender-</option>
  		<option value="M">Male</option>
  		<option value="F">Female</option>
  	</select>
  	<input type="text" name='txtAge' placeholder="Age" class='Age'>
  	<input type="date" name='txtbdate' placeholder="Birth date" class='bdate'>
  </div>
  <br/>
   <div>
   <select name='txtSY' class='classList' >
  		<option value="">-Select SY-</option>
  		<option value="2324">2023-2024</option>
  		<option value="2425">2024-2025</option>
  		<option value="2526">2025-2026</option>
  	</select>
  	<select name='txtSem' class='classList' >
  		<option value="">-Select Sem-</option>
  		<option value="A">1st Semester</option>
  		<option value="B">2nd Semester</option>
  	</select>
  	<select name='txtGrade' class='classList' >
  		<option value="">-Select Grade-</option>
  		<option value="11">Grade 11</option>
  		<option value="12">Grade 12</option>
  	</select>
  </div>
  <br/>
  <div><input type="text" name='txtSection' placeholder="Section" class='logInput'><div>
  <br/>
  <div>
  	<select type="text" name='txtStrand' class='logInput' >
  	<?=showCourse('')?>
  	</select>
  </div>
  <br/>
  

 <!--  <div>
  	<select  name='txtGender' style="height:40px;padding: 3px; font-size: 15px;margin-right: 30px;border-radius: 16px;"  ><?=showGender('')?></select> 
  	<select  name='txtYear' style="height:40px;padding: 3px; font-size: 15px;border-radius: 16px;"  ><?=showYearLevel('')?></select> 
   </div>
  <br/>
<div>
  	<select  name='txtCourse' style="height:40px; font-size: 15px;margin-bottom: 30px; width: 100%;border-radius: 16px;text-align: center;"  ><?=showCourse('')?></select> 
   </div> -->
<div style="margin-bottom: 5px;">
  <a href='#'class='logbutton' onclick='Signup()'>Submit</a>
</div>
<div>
  <a href='../process/choice2.php'class='logbutton'>Back</a>
</div>
	
</div>
</body>
<script>
	function Signup(){
		// alert();
		if($("[name=txtLName]").val()==''){
			$("[name=txtLName]").focus();
			alert('Last Name is Required');
			return;
		}
		if($("[name=txtFName]").val()==''){
			$("[name=txtFName]").focus();
			alert('First Name is Required');
			return;
		}
		if($("[name=txtMName]").val()==''){
			$("[name=txtMName]").focus();
			alert('Middle Name is Required');
			return;
		}
		if($("[name=txtGender]").val()==''){
			$("[name=txtGender]").focus();
			alert('Gender is Required');
			return;
		}
		if($("[name=txtAge]").val()==''){
			$("[name=txtAge]").focus();
			alert('Age is Required');
			return;
		}
		if($("[name=txtbdate]").val()==''){
			$("[name=txtbdate]").focus();
			alert('Birth Date is Required');
			return;
		}
		if($("[name=txtSY]").val()==''){
			$("[name=txtSY]").focus();
			alert('School Year is Required');
			return;
		}
		if($("[name=txtSem]").val()==''){
			$("[name=txtSem]").focus();
			alert('Semester is Required');
			return;
		}
		if($("[name=txtGrade]").val()==''){
			$("[name=txtGrade]").focus();
			alert('Grade Level is Required');
			return;
		}
		if($("[name=txtSection]").val()==''){
			$("[name=txtSection]").focus();
			alert('Section is Required');
			return;
		}
		if($("[name=txtStrand]").val()==''){
			$("[name=txtStrand]").focus();
			alert('Strand is Required');
			return;
		}


		// $("[name=txtUserName]").val();
	// 	 $.ajax({
  //       url: "../process/createAccount.php",
  //       type: "post",
  //       data: {
  //         hjob: 'createDummy',
  //         txtLName: $("[name=txtLName]").val(),
  //         txtEmail: $("[name=txtEmail]").val(),
  //         txtPass: $("[name=txtPass]").val(),
  //         // txtPass2: $("[name=txtPass]").val(),
  //         // txtGender: $("[name=txtcon]").val(),
  //         // txtYear: $("[name=txtYear]").val(),
  //         // txtStrand: $("[name=txtStrand]").val(),
  //       },
  //       success: function(msg) {
  //       	if(msg==1){
  //       	alert('Name Already Exist...');
	// 				$("[name=txtName]").focus();	
  //       	}else if(msg==3){
  //       		alert('txtEmail Already Exist...');
	// 				$("[name=txtName]").focus();	
  //       	}else{
  //       		if(confirm('Create Account success \n Do you want to redirect to Login Page?')){
  //       window.location.href = '../process/login.php';
  //       		}else{
  //       			location.reload();
  //       		}
  //       	}
  //       }
  //     });
	}
</script>
</html>