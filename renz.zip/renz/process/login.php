<?php
include "../includes/db.php";          
include "../includes/functions.php";          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/login.css">
    <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>

<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body  >
	<div class="bg-image"></div>
	<div class="bg-text">
	<div align="right">  <a href='../process/choice2.php'class='logbutton'>Back</a></div>
  <div><img src='../images/iccLogo.png'  width='150px' height='150px'></div>
  <div><input type="text" name='txtUserName' placeholder="Enter Your User Name" class='logInput'></div>
  <br/>
  <div><input type="password" name='txtPassword' placeholder="Enter Your Password" class='logInput'></div>
  <br/>
<div>
  <a href='#' type='button' class='logbutton' onclick='Login()'>Login</a>
</div>
  <br/>
<div>
  <a href='../process/signup.php'class='logbutton'>No Account? Sign Up</a>
</div>
	
</div>
</body>
<script>


	function Login(){
		if($("[name=txtUserName]").val()==''){
			$("[name=txtUserName]").focus();
			alert('Email is Required');
			return;
		}
		if($("[name=txtPassword]").val()==''){
			$("[name=txtPassword]").focus();
			alert('Password is Required');
			return;
		}
		 $.ajax({
        url: "../process/createAccount.php",
        type: "post",
        data: {
          hjob: 'login',
          UserName: $("[name=txtUserName]").val(),
          Password: $("[name=txtPassword]").val(),
        },
        success: function(msg) {
        	if(msg==1){
        		alert('Success Login');
        window.location.href = '../process/dashboard.php';
        	}else{
        		alert('Invalid Credential... \n Please Try Again !!');
        	}
        }
      });
	}
</script>
</html>