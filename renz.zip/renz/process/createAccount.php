<?php
include "../includes/db.php";          
include "../includes/functions.php";          
session_start();
// foreach($_POST as $k=>$v) $p[$k] = mysql_real_escape_string($v);
switch ($_POST['hjob']) {
	case 'creacteAcct':
	$txtName = $_POST['txtName'];
	$pass = md5($_POST['txtPass']);
	$txtEmail = $_POST['txtEmail'];
$ExistName = mysqli_num_rows(safe_query("SELECT * FROM tblpersonaldata WHERE Name='{$txtName}' "));
$ExistEmail = mysqli_num_rows(safe_query("SELECT * FROM tblpersonaldata WHERE Email='{$txtEmail}' "));
if($ExistName>0){
	ob_clean();
	echo 1;
}else{
	if($ExistEmail>0){
	ob_clean();
	echo 3;
	}else{
	safe_query("INSERT INTO tblpersonaldata(Name,Password,Email) VALUES('{$txtName}','{$pass}','{$txtEmail}')");
ob_clean();
echo 2;
}
}
		break;

	case 'login':
	$Pass = md5($_POST['Password']);
	$UserName = $_POST['UserName'];
$accountTRUE = safe_query("SELECT * FROM tblpersonaldata WHERE Email='{$UserName}' AND Password='{$Pass}' ");
if(mysqli_num_rows($accountTRUE)>0){
	$pdata = mysqli_fetch_assoc($accountTRUE);
	$_SESSION['user'] = $pdata['Name'];
	$_SESSION['Email'] = $UserName;
	ob_clean();
	echo 1;
}else{
	ob_clean();
	echo 2;
}

	break;
}

?>