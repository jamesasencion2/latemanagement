<?php
include "../includes/db.php";          
include "../includes/functions.php";          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/login.css">
    <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>
      <!-- <link rel='stylesheet' type='text/css' href='../design/gsheet.css'> -->
<!-- <link rel='stylesheet' type='text/css' href='../design/jquery-ui.css' /> -->
<!-- <script type='text/javascript' src='../js/jquery-ui.js'></script> -->
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body  >
	<div class="bg-image"></div>
	<div class="bg-textsign" style="width: 34%;">
  <div><img src='../images/iccLogo.png'  width='150px' height='150px'></div>
  <br/>
  <div align="center"><h2>Create An Account</h2></div>
  <!-- <br/> -->
  <div><input type="text" name='txtName' placeholder="Enter Your Full Name" class='logInput'></div>
  <br/>
  <div><input type="Email" name='txtEmail' placeholder="Enter Your Email" class='logInput'></div>
  <br/>
  <div><input type="password" name='txtPass' placeholder="Create Your Password" class='logInput'></div>
  <br/>
   <div><input type="password" name='txtPass2' placeholder="Confirm  Password" class='logInput'></div>
  <br/>

 <!--  <div>
  	<select  name='txtGender' style="height:40px;padding: 3px; font-size: 15px;margin-right: 30px;border-radius: 16px;"  ><?=showGender('')?></select> 
  	<select  name='txtYear' style="height:40px;padding: 3px; font-size: 15px;border-radius: 16px;"  ><?=showYearLevel('')?></select> 
   </div>
  <br/>
<div>
  	<select  name='txtCourse' style="height:40px; font-size: 15px;margin-bottom: 30px; width: 100%;border-radius: 16px;text-align: center;"  ><?=showCourse('')?></select> 
   </div> -->
<div style="margin-bottom: 5px;">
  <a href='#'class='logbutton' onclick='Signup()'>Submit</a>
</div>
<div>
  <a href='../process/choice2.php'class='logbutton'>Back</a>
</div>
	
</div>
</body>
<script>
	function Signup(){
		// alert();
		if($("[name=txtName]").val()==''){
			$("[name=txtName]").focus();
			alert('User Name is Required');
			return;
		}
		if($("[name=txtEmail]").val()==''){
			$("[name=txtEmail]").focus();
			alert('Email is Required');
			return;
		}
		if($("[name=txtPass]").val()==''){
			$("[name=txtPass]").focus();
			alert('Create Password is Required');
			return;
		}
		if($("[name=txtPass2]").val()==''){
			$("[name=txtPass2]").focus();
			alert('Confirm Password is Required');
			return;
		}
		if($("[name=txtPass]").val()!=$("[name=txtPass2]").val()){
			// $("[name=txtPass2]").focus();
			alert('Password not match');
			return;
		}
		// $("[name=txtUserName]").val();
		 $.ajax({
        url: "../process/createAccount.php",
        type: "post",
        data: {
          hjob: 'creacteAcct',
          txtName: $("[name=txtName]").val(),
          txtEmail: $("[name=txtEmail]").val(),
          txtPass: $("[name=txtPass]").val(),
          // txtPass2: $("[name=txtPass]").val(),
          // txtGender: $("[name=txtcon]").val(),
          // txtYear: $("[name=txtYear]").val(),
          // txtCourse: $("[name=txtCourse]").val(),
        },
        success: function(msg) {
        	if(msg==1){
        	alert('Name Already Exist...');
					$("[name=txtName]").focus();	
        	}else if(msg==3){
        		alert('txtEmail Already Exist...');
					$("[name=txtName]").focus();	
        	}else{
        		if(confirm('Create Account success \n Do you want to redirect to Login Page?')){
        window.location.href = '../process/login.php';
        		}else{
        			location.reload();
        		}
        	}
        }
      });
	}
</script>
</html>