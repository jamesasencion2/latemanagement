<?php
include "../includes/db.php";          
include "../includes/functions.php";          
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="../design/login.css">
 <link rel='stylesheet' type='text/css' href='../css/bootstrap.css'>
<script language="JavaScript" src="../js/ajax.js"></script>
<script language='javascript' src='../js/jquery.js'></script>
	<title>Login Module</title>
</head>
<body  >
	<div class="bg-image"></div>
	<div class="bg-choice">
  <div><img src='../images/iccLogo.png'  width='250px' height='250px'></div>
  <div></div>
  <br/>
  <div align="center">
  	<div style="background-color: white; width: 220px;height:50px;border-radius: 16px;" >
  		<input type="button" value="Teacher" class='buttonchoce' onclick="redirectF('../process/choice2.php')" style="margin:5px;background-color: #F4D047;color: #193867;" >
  </div>
  </div>
  <br/>
  <div align="center" style=""><div style="background-color: white; width: 220px;height:50px;border-radius: 16px;" align="center">
  	<input type="button" value="Admin" class='buttonchoce' onclick="underM()" style="margin:5px;background-color: #F4D047;color: #193867;">
 </div>
 </div>
  <br/>
	
</div>
</body>
<script>
	function redirectF(url){
        window.location.href = url;
	}
	function underM(){
		alert('Admin is Under Maintenance');
	}
</script>
</html>