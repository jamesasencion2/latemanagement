<?php


function safe_query($sql = "")
{
	global $con;
  if (empty($sql)) {
    return FALSE;
  }
  $result =  mysqli_query($con, $sql);
  // if (!$result) echo displayError($sql, mysql_error());
 
  return $result;
}
function showYearLevel($sel){
		$G11='';
		$G12='';
	if($sel==11){
		$G11='selected';
	}else if($sel==12){
		$G12='selected';
	}
	$result='';
	$result .="<option value='' >- Select Grade -</option>";
	$result .="<option value='11' ".$G11.">Grade 11</option>";
	$result .="<option value='12' ".$G12.">Grade 12</option>";

	return $result;
}
function showGender($sel){
		$m='';
		$f='';
	if($sel==11){
		$m='selected';
	}else if($sel==12){
		$f='selected';
	}
	$result='';
	$result .="<option value='' >- Select Gender -</option>";
	$result .="<option value='M' ".$m.">Male</option>";
	$result .="<option value='F' ".$f.">Female</option>";

	return $result;
}
function showCourse($sel){
	$result ="<option value='' >-Select Strand-</option>";

	$sql=safe_query("SELECT * FROM tblcourses");
	// $sqls = mysqli_query($con, $sql);
	while ($row=mysqli_fetch_array($sql)) {
	if($row['CourseCode']==$sel){
	$result .="<option value='{$row['CourseCode']}' selected >{$row['Description']}</option>";
	}else{
	$result .="<option value='{$row['CourseCode']}' >{$row['Description']}</option>";
	}	
	}
	// $rows = mysqli_num_rows($sql);
	// $result .="<option value='F' ".$f.">Female</option>";

	return $result;
}

function encryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

function decryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
    return( $qDecoded );
}
?>