-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 03:33 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `studpersonaldata`
--

CREATE TABLE `studpersonaldata` (
  `StudID` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(11) NOT NULL,
  `Bdate` date NOT NULL,
  `LName` varchar(100) NOT NULL,
  `MName` varchar(100) NOT NULL,
  `FName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblcourses`
--

CREATE TABLE `tblcourses` (
  `CourseCode` varchar(50) NOT NULL,
  `Description` varchar(250) NOT NULL,
  `Department` varchar(10) NOT NULL,
  `HMYears` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcourses`
--

INSERT INTO `tblcourses` (`CourseCode`, `Description`, `Department`, `HMYears`) VALUES
('ABM', 'ACOUNTANCY AND BUSINESS MANAGEMENT', 'SHS', 2),
('GAS', 'GENERAL ACADEMIC STRAND', 'SHS', 2),
('HE', 'HOME ECONOMICS', 'SHS', 2),
('HUMSS', 'HUMANITIES AND SOCIAL SCIENCES', 'SHS', 2),
('ICT', 'INFORMATIO AND COMMUNICATION TECHNOLOGY', 'SHS', 2),
('STEM', 'SCIENCE, ENGINEERING, TECHNOLOGY, AND MATHEMATICS', 'SHS', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblpersonaldata`
--

CREATE TABLE `tblpersonaldata` (
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblpersonaldata`
--

INSERT INTO `tblpersonaldata` (`Name`, `Email`, `Password`) VALUES
('nolan', 'nolan@gmail.com', 'b443ee863927aa4151866f12cc13ea1d'),
('renz  bernardino', 'renz@gmail.com', '4297f44b13955235245b2497399d7a93'),
('', '', 'd41d8cd98f00b204e9800998ecf8427e');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudlatetble`
--

CREATE TABLE `tblstudlatetble` (
  `id` int(11) NOT NULL,
  `StudID` varchar(30) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tlbstudclasslist`
--

CREATE TABLE `tlbstudclasslist` (
  `StudID` varchar(50) NOT NULL,
  `CourseCode` varchar(150) NOT NULL,
  `Grade` varchar(20) NOT NULL,
  `Section` varchar(100) NOT NULL,
  `SY` varchar(15) NOT NULL,
  `Sem` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcourses`
--
ALTER TABLE `tblcourses`
  ADD PRIMARY KEY (`CourseCode`);

--
-- Indexes for table `tblstudlatetble`
--
ALTER TABLE `tblstudlatetble`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblstudlatetble`
--
ALTER TABLE `tblstudlatetble`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
