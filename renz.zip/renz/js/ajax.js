var hReq = new Array();    // ARRAY OF XML-HTTP REQUESTS
var xIDX = new Array(0);    // ARRAY OF XML-HTTP REQUEST INDEXES
xIDX[0] = 1;                // FIRST INDEX SET TO 1 MAKING IT AVAILABLE

function newRequestObj() {
  // find the correct xmlHTTP, works with IE, FF and Opera
  var xmlhttp;
  try {
    xmlhttp=new ActiveXObject("Msxml2.XMLHTTP");
  }
  catch(e) {
    try {
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    catch(e) {
      xmlhttp=null;
    }
  }
  if(!xmlhttp&&typeof XMLHttpRequest!="undefined") {
    xmlhttp=new XMLHttpRequest();
  }
  return  xmlhttp;
}

function XMLhttpsender(objXML,url,typS,ParamPost){
  if(typS=="POST"){
    objXML.open("POST", url);
    objXML.setRequestHeader('Content-Type',  "application/x-www-form-urlencoded");
    // objXML.setRequestHeader('Content-length',  ParamPost.length);
    // objXML.setRequestHeader('Connection',  "close");
    objXML.send(ParamPost);
 }else{
    objXML.open("GET", url + ParamPost);
    objXML.send(null);
 }
}

function getAvailableIDX(){
  var rIDX = xIDX.length;
  //go through available xi values
  for (var i=0; i<xIDX.length; i++) {
    //if it's 1 (available), allocate it for use and break
    if (xIDX[i] == 1) {
      xIDX[i] = 0;
      rIDX = i;
      break;
    }
  }
  return rIDX;
}

function setActive(imgName,val,doc)
{
  for(x=0;x<doc.frmReg.elements.length;x++)
    {
      if(doc.frmReg.elements[x].name==imgName && doc.frmReg.elements[x].value==val)
        {
          doc.frmReg.elements[x].border = 3;
          break;
        }
    }
}

function postRemarks(url,params) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
          var resXML = hReq[rIDX].responseXML;
          var response = resXML.documentElement;
          var done = response.getElementsByTagName('status')[0].firstChild.nodeValue==1;
          var remarks = response.getElementsByTagName('remarks')[0].firstChild.nodeValue;
          var remarksID = response.getElementsByTagName('remarksID')[0].firstChild.nodeValue;
          
          if(done){
            var selObjs = document.getElementsByTagName("select");
            for(var i=0; i < selObjs.length; i++){
              var selObj = selObjs[i];
              if(selObj.getAttribute("rel_name") == "cboRemarks"){
                selObj.options[selObj.options.length] = new Option(remarks);                
                selObj.options[selObj.options.length-1].value = remarksID;
                //selObj.options[selObj.options.length-1].selected = defObj.getAttribute("rel_idx") == selObj.getAttribute("rel_idx");                
                selObj.options[selObj.options.length] = selObj.options[selObj.options.length-2];
              } 
            } 
          };
        }
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function processParams(url,params,msg) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
          var resXML = hReq[rIDX].responseXML;
          var response = resXML.documentElement;
          var done = response.getElementsByTagName('status')[0].firstChild.nodeValue==1;
          if(done && msg != "") alert(msg);
        }
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function refreshContent(url,elementID,newEvent) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  var ImS = "../images/loading.gif";
  var HTMLVals = "";

  HTMLVals = "<img src="+ ImS +">&nbsp;<span class='regu'>Loading...</span>";

  document.getElementById(elementID).innerHTML = HTMLVals;
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
            document.getElementById(elementID).innerHTML = hReq[rIDX].responseText;
            if(newEvent) newEvent();
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
        xIDX[rIDX] = 1;
        hReq[rIDX] = null;
    }
  };
  hReq[rIDX].open('GET', url, true);
  hReq[rIDX].send(null);
}

function makeRequest(url,elementID,header,footer) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  var ImS = "../images/jump_ball.gif";
  var HTMLVals = "";

  HTMLVals = "<table border=0 height='100%' cellspacing=0 cellpadding=0 width='100%' style='overflow-x:hidden;'>";
  HTMLVals += "<tr>";
  HTMLVals += "<td width='10'>&nbsp;</td>";
  HTMLVals += "<td width='620' align='center' class='regu'><img src="+ ImS +"><br><font color=blue size=+1><b>Loading...</b></font></td>";
  HTMLVals += "<td width='10'>&nbsp;</td>";
  HTMLVals += "</tr>";
  HTMLVals += "</table>";

  document.getElementById(elementID).innerHTML = HTMLVals;
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
            document.getElementById(elementID).innerHTML = header+hReq[rIDX].responseText+footer;
            //alert(http_request.responseText);
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('GET', url, true);
  hReq[rIDX].send(null);
}

function execNext(url,elementID,nextEvent) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
            document.getElementById(elementID).innerHTML = hReq[rIDX].responseText;
            if(typeof nextEvent=="function") nextEvent();
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('GET', url, true);
  hReq[rIDX].send(null);
}

function makePostRequest(url,elementID,params,header,footer) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  document.getElementById(elementID).innerHTML = "Processing...";
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
            document.getElementById(elementID).innerHTML = header+hReq[rIDX].responseText+footer;
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function postParams(url,elementID,params) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  var def = "";
  
  def = "<img src='../images/loading.gif'>&nbsp;<span class='regu'>Loading...</span>";
  document.getElementById(elementID).innerHTML = def;
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
      document.getElementById(elementID).innerHTML = hReq[rIDX].responseText;
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function postVars(url,elementID,params,nextEvent) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  document.getElementById(elementID).innerHTML = "Processing...";
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
          var rtext = hReq[rIDX].responseText.split('a#a');
          document.getElementById(elementID).innerHTML = rtext[0];
          if(rtext[1]=='1') nextEvent();
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function postPage(url,elementID,params,nextEvent) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  document.getElementById(elementID).innerHTML = "Processing...";
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
          document.getElementById(elementID).innerHTML = hReq[rIDX].responseText;
          nextEvent();
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function postPayment(url,elementID,params,nextEvent,errorEvent) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  document.getElementById("shades").style.display = "block";
  //document.getElementById(elementID).innerHTML = "Processing...";

  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
          //alert(hReq[rIDX].responseText); 
          document.getElementById("shades").style.display = "none";
          var response = hReq[rIDX].responseXML.documentElement;
          var msg = response.getElementsByTagName('value')[0].firstChild.nodeValue;
          var success = response.getElementsByTagName('stat')[0].firstChild.nodeValue; 
          var studNo = response.getElementsByTagName('studNo')[0].firstChild.nodeValue;
          var receiptNo = response.getElementsByTagName('receiptNo')[0].firstChild.nodeValue;
          var deptType = response.getElementsByTagName('deptType')[0].firstChild.nodeValue;
          var payType = response.getElementsByTagName('payType')[0].firstChild.nodeValue;
          var transid = response.getElementsByTagName('transID')[0].firstChild.nodeValue;
          // console.log(response);return;
          //alert(success);
          if(success==1){
            //window.open("../process/pup_regform.pdf.php","_BLANK");
            //?="+studNo+"&="+receiptNo+"&="+deptType+"&="+payType  
            launch(studNo,receiptNo,deptType,payType,transid);
            if(typeof nextEvent=="function") nextEvent();
          }else if(success==2 || success==3){
            alert(msg);
            return;
          }else if(typeof errorEvent=="function"){
            document.getElementById(elementID).innerHTML = msg;
            errorEvent(); 
          }
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  // hReq[rIDX].setRequestHeader("Content-length", params.length);
  // hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function prepareSchedule(url,elementID,params,header,footer) {
  var rIDX = getAvailableIDX();

  xIDX[rIDX] = 0;
  hReq[rIDX] = newRequestObj();

  var ImS = "../images/jump_ball.gif";
  var HTMLVals = "";

  HTMLVals = "<table border=0 height='100%' cellspacing=0 cellpadding=0 width='100%'>";
  HTMLVals += "<tr>";
  HTMLVals += "<td width='10'>&nbsp;</td>";
  HTMLVals += "<td width='620' align='center' class='regu'><img src="+ ImS +"><br><font color=blue><b>Loading...</b></font></td>";
  HTMLVals += "<td width='10'>&nbsp;</td>";
  HTMLVals += "</tr>";
  HTMLVals += "</table>";
  document.getElementById(elementID).innerHTML = HTMLVals;
  hReq[rIDX].onreadystatechange = function() {
    if (hReq[rIDX].readyState == 4) {
        if (hReq[rIDX].status == 200) {
            document.getElementById(elementID).innerHTML = header+hReq[rIDX].responseText+footer;
        }
        else document.getElementById(elementID).innerHTML = 'There was a problem with the request.';
    }
  };
  hReq[rIDX].open('POST', url, true);
  hReq[rIDX].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  hReq[rIDX].setRequestHeader("Content-length", params.length);
  hReq[rIDX].setRequestHeader("Connection", "close");
  hReq[rIDX].send(params);
}

function getParams(allForms,objFrm){
  var str = "";
  if(allForms){
    for(var f=0;f<document.forms.length;f++){
      for(var v=0;v<document.forms[f].elements.length;v++){
        if(str!="") str += "&";
        str += document.forms[f].elements[v].name;
        str += "=" + encodeURIComponent(document.forms[f].elements[v].value);
      }
    }
  }
  else {
    for(var v=0;v<objFrm.elements.length;v++){
      if(str!="") str += "&";
      str += objFrm.elements[v].name;
      str += "=" + encodeURIComponent(objFrm.elements[v].value);
    }
  }
  return str;
}

function getFormParams(objFrm){
  var str = "";
  for(var v=0;v<objFrm.elements.length;v++){
    if(str!="") str += "&";
    str += objFrm.elements[v].name;
    str += "=" + encodeURIComponent(objFrm.elements[v].value);
  }
  return str;
}

function getOptionValue(objFrm,objName){
  var result = "";
  var fLen = objFrm.elements.length;
  for(var v=0;v<fLen;v++){
    obj = objFrm.elements[v];
    if(obj.name==objName){
      if((obj.type=="radio" || obj.type=="checkbox") && obj.checked){
        result = obj.value;
        break;
      }
    }
  }
  return result;
}

function authenticateUser(objFrm){
  if(objFrm.usr.value==""){
    alert("Username is required!");
    objFrm.usr.focus();
    return;
  }
  else if(objFrm.pwd.value==""){
    alert("Password cannot be blank!");
    objFrm.pwd.focus();
    return;
  }
  objFrm.btn.value="Please wait";
  objFrm.btn.disabled = true;
  objFrm.submit();
}

function validateUser(objFrm){
  if(objFrm.usr.value==""){
    alert("Username is required!");
    objFrm.usr.focus();
    return;
  }
  else if(objFrm.dpwd.value==""){
    alert("Password cannot be blank!");
    objFrm.dpwd.focus();
    return;
  }
  else if(objFrm.dpwd.value!=objFrm.cpwd.value){
    alert("Passwords are not the same. Please try again!");
    objFrm.cpwd.focus();
    return;
  }
  else if(objFrm.ln.value==""){
    alert("Last Name cannot be blank!");
    objFrm.ln.focus();
    return;
  }
  else if(objFrm.fn.value==""){
    alert("First Name cannot be blank!");
    objFrm.fn.focus();
    return;
  }
  objFrm.btn.value="Please wait";
  objFrm.btn.disabled = true;
  viewList();
}