<?php
header("Location: process/choice.php");
?>